const Database = require("better-sqlite3");
const fs = require("fs");
const path = require("path");
const config = require("./config");

const dbPath = path.resolve(config.databasePath);
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS usage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_hash TEXT NOT NULL,
    event TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_usage_created_at
  ON usage(created_at);
`);

const saveUsage = db.prepare(`
  INSERT INTO usage(session_hash, event) VALUES (?, ?)
`);

module.exports = { db, saveUsage };
