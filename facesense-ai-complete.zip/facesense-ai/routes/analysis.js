const express = require("express");
const crypto = require("crypto");
const router = express.Router();

const rateLimit = require("../middleware/rateLimit");
const { validateAnalysis } = require("../middleware/validation");
const { saveUsage } = require("../database");
const config = require("../config");

const hashSession = (session) =>
  crypto.createHash("sha256").update(session).digest("hex");

router.post("/", rateLimit(config.analysisRateLimit), validateAnalysis, (req, res) => {
  const session = req.get("X-Session-ID");

  if (!session || !/^[a-f0-9-]{36}$/i.test(session)) {
    return res.status(400).json({ error: "A valid anonymous session ID is required." });
  }

  try {
    // Only a hashed session identifier and event type are stored.
    // Facial images, video, and metric values are not persisted.
    saveUsage.run(hashSession(session), "analysis_saved");
    res.json({
      success: true,
      message: "Analysis event recorded. Your detailed history stays on this device."
    });
  } catch (error) {
    console.error("Analysis storage error:", error.message);
    res.status(500).json({ error: "Could not save the event." });
  }
});

module.exports = router;
