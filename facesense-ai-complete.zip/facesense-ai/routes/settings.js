const express = require("express");
const router = express.Router();

// Public defaults are read-only. Each visitor's choices stay in their browser.
router.get("/", (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({
    enhancement: true,
    smoothing: true,
    processingMode: "balanced",
    targetProcessingFps: 15
  });
});

module.exports = router;
