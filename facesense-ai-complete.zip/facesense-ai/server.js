const express = require("express");
const helmet = require("helmet");
const path = require("path");
const config = require("./config");

require("./database");

const healthRoutes = require("./routes/health");
const analysisRoutes = require("./routes/analysis");
const settingsRoutes = require("./routes/settings");
const rateLimit = require("./middleware/rateLimit");

const app = express();
app.disable("x-powered-by");

app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: [
        "'self'",
        "'wasm-unsafe-eval'",
        "https://cdn.jsdelivr.net",
        "https://storage.googleapis.com"
      ],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: [
        "'self'",
        "https://cdn.jsdelivr.net",
        "https://storage.googleapis.com"
      ],
      workerSrc: ["'self'", "blob:"],
      mediaSrc: ["'self'", "blob:"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"]
    }
  }
}));

app.use(rateLimit());
app.use(express.json({ limit: config.maxRequestBytes }));

app.use("/api/health", healthRoutes);
app.use("/api/analysis", analysisRoutes);
app.use("/api/settings", settingsRoutes);

app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"]
}));

app.use("/api", (req, res) => {
  res.status(404).json({ error: "API endpoint not found." });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use((err, req, res, next) => {
  console.error("Server error:", err.message);
  if (res.headersSent) return next(err);
  res.status(err.status || 500).json({
    error: err.status === 413 ? "Request is too large." : "The server encountered an error."
  });
});

app.listen(config.port, "0.0.0.0", () => {
  console.log(`FaceSense AI running on port ${config.port}`);
});
