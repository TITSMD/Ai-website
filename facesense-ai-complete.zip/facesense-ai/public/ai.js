import {
  FaceLandmarker,
  FilesetResolver
} from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";

const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

let landmarker = null;
let previous = {};
let lastVideoTime = -1;

export async function loadAI() {
  if (landmarker) return landmarker;
  const vision = await FilesetResolver.forVisionTasks(WASM_URL);
  landmarker = await FaceLandmarker.createFromOptions(vision, {
    baseOptions: { modelAssetPath: MODEL_URL, delegate: "CPU" },
    runningMode: "VIDEO",
    numFaces: 1,
    outputFaceBlendshapes: true,
    outputFacialTransformationMatrixes: false
  });
  return landmarker;
}

function average(a,b){return(a+b)/2}
function clamp(v){return Math.max(0,Math.min(1,v||0))}
function smoothValue(name,value,enabled){
  value=clamp(value);
  if(!enabled){previous[name]=value;return value}
  const old=previous[name]??value;
  const result=old*.68+value*.32;
  previous[name]=result;
  return result;
}

export function enhanceFrame(video,canvas,enabled){
  const ctx=canvas.getContext("2d",{alpha:false});
  const width=640;
  const height=Math.max(1,Math.round(width*video.videoHeight/video.videoWidth));
  if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height}
  ctx.filter=enabled?"brightness(1.08) contrast(1.10) saturate(1.03)":"none";
  ctx.drawImage(video,0,0,width,height);
  ctx.filter="none";
  return canvas;
}

export function analyzeFrame(video,canvas,settings){
  if(!landmarker)throw new Error("AI model is not loaded.");
  if(video.readyState<2||video.currentTime===lastVideoTime)return null;
  lastVideoTime=video.currentTime;
  const frame=enhanceFrame(video,canvas,settings.enhancement);
  const result=landmarker.detectForVideo(frame,performance.now());
  if(!result.faceBlendshapes||result.faceBlendshapes.length===0)return null;
  const categories=result.faceBlendshapes[0].categories;
  const values={};
  for(const item of categories)values[item.categoryName]=item.score;
  const smile=average(values.mouthSmileLeft||0,values.mouthSmileRight||0);
  const brow=average(values.browDownLeft||0,values.browDownRight||0);
  return {
    smile:smoothValue("smile",smile,settings.smoothing),
    jawOpen:smoothValue("jawOpen",values.jawOpen,settings.smoothing),
    eyeBlinkLeft:smoothValue("eyeBlinkLeft",values.eyeBlinkLeft,settings.smoothing),
    eyeBlinkRight:smoothValue("eyeBlinkRight",values.eyeBlinkRight,settings.smoothing),
    browInnerUp:smoothValue("browInnerUp",values.browInnerUp,settings.smoothing),
    browDownLeft:smoothValue("browDownLeft",values.browDownLeft,settings.smoothing),
    browDownRight:smoothValue("browDownRight",values.browDownRight,settings.smoothing),
    mouthFunnel:smoothValue("mouthFunnel",values.mouthFunnel,settings.smoothing),
    mouthPucker:smoothValue("mouthPucker",values.mouthPucker,settings.smoothing),
    browMovement:smoothValue("browMovement",brow,settings.smoothing)
  };
}

export function closeAI(){
  if(landmarker){landmarker.close();landmarker=null}
  previous={};
  lastVideoTime=-1;
}
