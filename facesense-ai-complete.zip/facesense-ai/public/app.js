import { loadAI, analyzeFrame, closeAI } from "./ai.js";

const $ = id => document.getElementById(id);
const video=$("video"), canvas=$("processedCanvas");
const startButton=$("startButton"), stopButton=$("stopButton");
const switchButton=$("switchButton"), saveButton=$("saveButton");
const settings={
  enhancement:localStorage.getItem("enhancement")!=="false",
  smoothing:localStorage.getItem("smoothing")!=="false"
};
let stream=null,running=false,facingMode="user",animationId=null;
let latestMetrics=null,lastProcessTime=0,frames=0,fpsStart=performance.now();
function getSessionId(){
  let id=localStorage.getItem("faceSession");
  if(!id){id=crypto.randomUUID();localStorage.setItem("faceSession",id)}
  return id;
}
const sessionId=getSessionId();
function setStatus(text){$("faceStatus").textContent=text}
function showMessage(text){$("saveMessage").textContent=text}
function percentage(value){return Math.round((value||0)*100)}
function updateMetric(name,value){
  const p=percentage(value);
  $(name+"Value").textContent=p+"%";
  $(name+"Bar").style.width=p+"%";
}
function updateResults(data){
  updateMetric("smile",data.smile);
  updateMetric("mouth",data.jawOpen);
  updateMetric("leftEye",data.eyeBlinkLeft);
  updateMetric("rightEye",data.eyeBlinkRight);
  updateMetric("brow",data.browMovement);
  $("noFace").hidden=true;$("metrics").hidden=false;saveButton.disabled=false;
  const movements=[];
  if(data.smile>.45)movements.push("smile-like movement");
  if(data.jawOpen>.4)movements.push("mouth open");
  if(data.eyeBlinkLeft>.55||data.eyeBlinkRight>.55)movements.push("eye blink");
  if(data.browMovement>.35)movements.push("brow movement");
  $("movementText").textContent=movements.length?"Detected: "+movements.join(", "):"No strong facial movement detected.";
  $("faceOverlay").textContent="FACE TRACKED";setStatus("Face detected");
}
function showNoFace(){
  latestMetrics=null;$("noFace").hidden=false;$("metrics").hidden=true;
  saveButton.disabled=true;$("movementText").textContent="No face detected.";
  $("faceOverlay").textContent="SEARCHING FOR FACE";setStatus("Looking for face");
}
async function startCamera(){
  if(!navigator.mediaDevices?.getUserMedia){alert("Camera access requires HTTPS or localhost.");return}
  try{
    stopCamera();setStatus("Requesting camera...");
    stream=await navigator.mediaDevices.getUserMedia({
      audio:false,
      video:{facingMode:{ideal:facingMode},width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30,max:30}}
    });
    video.srcObject=stream;await video.play();
    $("cameraPlaceholder").hidden=true;
    startButton.disabled=true;stopButton.disabled=false;switchButton.disabled=false;
    setStatus("Loading AI model...");
    await loadAI();
    running=true;lastProcessTime=0;frames=0;fpsStart=performance.now();
    setStatus("AI ready");processLoop();
  }catch(error){
    console.error(error);stopCamera();setStatus("Camera or AI error");
    alert("Could not start camera or AI. Check camera permission and internet connection, then try again.");
  }
}
function stopCamera(){
  running=false;
  if(animationId!==null){cancelAnimationFrame(animationId);animationId=null}
  if(stream){stream.getTracks().forEach(track=>track.stop());stream=null}
  video.srcObject=null;startButton.disabled=false;stopButton.disabled=true;
  $("cameraPlaceholder").hidden=false;latestMetrics=null;showNoFace();
  $("fps").textContent="0 FPS";
}
function processLoop(now=performance.now()){
  if(!running)return;
  animationId=requestAnimationFrame(processLoop);
  if(now-lastProcessTime<66)return;
  lastProcessTime=now;
  try{
    const result=analyzeFrame(video,canvas,settings);
    if(result){latestMetrics=result;updateResults(result)}else showNoFace();
    frames++;
    if(now-fpsStart>=1000){
      $("fps").textContent=Math.round(frames*1000/(now-fpsStart))+" FPS";
      frames=0;fpsStart=now;
    }
  }catch(error){console.error("Detection error:",error);setStatus("Detection error")}
}
async function saveAnalysis(){
  if(!latestMetrics)return;
  saveButton.disabled=true;showMessage("Saving summary...");
  try{
    const response=await fetch("/api/analysis",{
      method:"POST",
      headers:{"Content-Type":"application/json","X-Session-ID":sessionId},
      body:JSON.stringify({metrics:latestMetrics})
    });
    const result=await response.json();
    if(!response.ok)throw new Error(result.error||"Save failed");
    const entry={date:new Date().toLocaleString(),metrics:latestMetrics};
    const history=getHistory();history.unshift(entry);
    localStorage.setItem("faceHistory",JSON.stringify(history.slice(0,30)));
    renderHistory();showMessage("Saved on this device.");
  }catch(error){console.error(error);showMessage("Could not save: "+error.message)}
  finally{saveButton.disabled=!latestMetrics}
}
function getHistory(){
  try{return JSON.parse(localStorage.getItem("faceHistory")||"[]")}catch{return[]}
}
function renderHistory(){
  const history=getHistory(),container=$("history");container.replaceChildren();
  if(!history.length){container.textContent="No saved results.";return}
  history.forEach(entry=>{
    const item=document.createElement("div");item.className="history-item";
    const date=document.createElement("strong");date.textContent=entry.date;
    const detail=document.createElement("div");
    detail.textContent="Smile: "+percentage(entry.metrics.smile)+"% · Mouth: "+percentage(entry.metrics.jawOpen)+"% · Left blink: "+percentage(entry.metrics.eyeBlinkLeft)+"%";
    item.append(date,detail);container.appendChild(item);
  });
}
function setupSettings(){
  const enhancement=$("enhancementToggle"),smoothing=$("smoothingToggle");
  enhancement.checked=settings.enhancement;smoothing.checked=settings.smoothing;
  enhancement.addEventListener("change",()=>{
    settings.enhancement=enhancement.checked;
    localStorage.setItem("enhancement",String(settings.enhancement));
  });
  smoothing.addEventListener("change",()=>{
    settings.smoothing=smoothing.checked;
    localStorage.setItem("smoothing",String(settings.smoothing));
  });
}
async function checkServer(){
  try{
    const response=await fetch("/api/health");
    if(!response.ok)throw new Error("Offline");
    const data=await response.json();
    $("serverStatus").textContent=data.status==="online"?"● Backend online":"Backend error";
  }catch{$("serverStatus").textContent="● Backend offline"}
}
startButton.addEventListener("click",startCamera);
stopButton.addEventListener("click",stopCamera);
switchButton.addEventListener("click",async()=>{
  facingMode=facingMode==="user"?"environment":"user";
  if(running)await startCamera();
});
saveButton.addEventListener("click",saveAnalysis);
$("clearHistory").addEventListener("click",()=>{
  if(!confirm("Delete saved history on this device?"))return;
  localStorage.removeItem("faceHistory");renderHistory();
});
window.addEventListener("pagehide",()=>{stopCamera();closeAI()});
setupSettings();renderHistory();checkServer();
