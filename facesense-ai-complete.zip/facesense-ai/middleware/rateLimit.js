const config = require("../config");

const buckets = new Map();

function rateLimit(max = config.generalRateLimit) {
  return (req, res, next) => {
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const now = Date.now();
    let bucket = buckets.get(key);

    if (!bucket || now - bucket.start >= config.rateLimitWindowMs) {
      bucket = { start: now, count: 0 };
      buckets.set(key, bucket);
    }

    bucket.count += 1;

    res.setHeader("RateLimit-Limit", String(max));
    res.setHeader("RateLimit-Remaining", String(Math.max(0, max - bucket.count)));

    if (bucket.count > max) {
      return res.status(429).json({
        error: "Too many requests. Please wait a moment."
      });
    }

    next();
  };
}

setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (now - bucket.start > config.rateLimitWindowMs * 2) {
      buckets.delete(key);
    }
  }
}, 60_000).unref();

module.exports = rateLimit;
