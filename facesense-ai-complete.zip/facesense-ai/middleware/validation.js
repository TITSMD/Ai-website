const ALLOWED_METRICS = [
  "smile",
  "jawOpen",
  "eyeBlinkLeft",
  "eyeBlinkRight",
  "browInnerUp",
  "browDownLeft",
  "browDownRight",
  "mouthFunnel",
  "mouthPucker",
  "browMovement"
];

function validateAnalysis(req, res, next) {
  const body = req.body || {};
  const source = body.metrics;

  if (!source || typeof source !== "object" || Array.isArray(source)) {
    return res.status(400).json({ error: "Invalid metrics object." });
  }

  const metrics = {};

  for (const key of ALLOWED_METRICS) {
    if (source[key] === undefined) continue;
    const value = source[key];

    if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1) {
      return res.status(400).json({ error: `Invalid metric: ${key}` });
    }

    metrics[key] = value;
  }

  if (Object.keys(metrics).length === 0) {
    return res.status(400).json({ error: "No valid metrics were supplied." });
  }

  req.validatedMetrics = metrics;
  next();
}

module.exports = { validateAnalysis };
