# FaceSense AI

A free, public facial-movement analyzer with a Node.js/Express backend and browser-based MediaPipe Face Landmarker.

## Requirements
- Node.js 20 or newer
- npm
- Internet connection for downloading the MediaPipe library and model
- HTTPS (or localhost) for camera access

## Run locally
```bash
npm install
npm start
```
Open http://localhost:3000

## Replit
1. Create a Node.js Repl.
2. Upload this ZIP and extract its contents into the project root (the `package.json` must be at the root).
3. Open Shell and run `npm install`.
4. Run `npm start`.
5. Use Replit's publish/deploy feature to get an HTTPS public URL.
6. Test the deployed URL on another device and allow camera access.

## API
- `GET /api/health` - server health
- `GET /api/settings` - read-only public defaults
- `POST /api/analysis` - records an anonymous usage event

Example POST body:
```json
{
  "metrics": {
    "smile": 0.5,
    "jawOpen": 0.2
  }
}
```
Include header `X-Session-ID` with a UUID and `Content-Type: application/json`.

## Privacy
- Camera frames are processed in the visitor's browser.
- No video or image is sent to the backend.
- Saved detailed results are kept in that browser's localStorage.
- The server stores only a SHA-256 hash of the anonymous session ID, event type, and timestamp when a visitor presses Save.
- Clearing browser storage removes local saved history.

## Limitations
This app measures visible facial movements; it does not identify a person's true emotions. Frame enhancement is lightweight brightness/contrast/saturation adjustment, not generative image restoration. The in-memory rate limiter is a starter safeguard, not a substitute for a distributed production rate limiter.
