module.exports = {
  port: Number(process.env.PORT) || 3000,
  databasePath: process.env.DATABASE_PATH || "./data/facesense.db",
  maxRequestBytes: "16kb",
  rateLimitWindowMs: 60_000,
  generalRateLimit: 100,
  analysisRateLimit: 15
};
